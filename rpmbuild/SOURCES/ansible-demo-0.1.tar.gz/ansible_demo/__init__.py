# ansible_demo/__init__.py
