# nexgy-demo
# Ansible Demo Package

This packege allows running Ansible playbooks from the command line
